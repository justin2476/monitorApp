import { Component, OnInit } from '@angular/core';

import {SignupService} from '../signup.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  display = false;
  apiData: object;
  newData = [];
  totalData: any;
  dailyCount = [];

  constructor(private apiService: SignupService) { }

  ngOnInit() {

    this.newData.push( {name: 'justin', totalCount: 6, points: 18, avgCount: 6, avgPoints: 18} );
  }

  onClick() {
    if (this.display === false) {
this.display = true;
    } else {
  console.log(localStorage.getItem('fromDate'));
  this.apiService.getWorkDate(localStorage.getItem('fromDate')).subscribe(data => {

    this.totalData = data;
    console.log(this.totalData);
    this.totalData.forEach(item => {
      var newUser={firstName:""};
      this.apiService.getUser(item.mobile).subscribe(user => {newUser=user});
        console.log(newUser);
        const fullName = newUser;
        const c = this.dailyCount.map(e => e.mobile).indexOf(item.mobile);
        if (c === -1) {
               const count = 1;
               const obj = {
                              mobile : item.mobile,
                              name : fullName,
                              count
                          };
               this.dailyCount.push(obj);
                      } else {
               this.dailyCount[c].count += 1;
                      }
              

            });
  } );

  this.display = false;
}
}

}
