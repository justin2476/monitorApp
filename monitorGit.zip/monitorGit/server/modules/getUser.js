var user = require('../model/user');
async function getUser(apiData) {
    return new Promise((resolve, reject) => {
        var query = {};
        console.log(apiData)
        if (apiData.mobile)
        query.mobile=apiData.mobile;
        else
        resolve([]);
        user.findOne(query,function(err,doc){

            if(err)
            resolve([]);
            else
            resolve(doc)
        })

    })
}

module.exports = { 'getUser': getUser }
