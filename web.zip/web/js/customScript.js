
 function myFunction() {
  alert("inMyfunction")

  try{
           var firstName=document.getElementById("firstName").value;

           var lastName=document.getElementById("lastName").value;

           var userId=document.getElementById("userId").value;
           var password=document.getElementById("password").value;
           var mobile=document.getElementById("mobile").value;
                  //     var role=document.getElementById("role").value;
  }
  catch(error)
  {
   alert(error);
  }     
                      alert(firstName)
try{
var formData = {};
formData.firstName=firstName;
formData.lastName =lastName;
formData.userId =userId;
formData.password =password;
formData.mobile =mobile;

alert(formData.mobile)
}
catch(error)
{
 alert(error);
}  
   // formData.append('firstName',firstName);
   // formData.append('lastName',lastName);
   // formData.append('userId',userId);
   // formData.append('password',password);   
   // formData.append('mobile',mobile);   

alert("tring call axios "+formData.mobile)
try{
   axios.post("http://localhost:4000/createUser",formData).then((response) => {
         alert(response);
         if(response.data=="work posted")
         alert("Registered Successfully")
         else
         alert("data Issue")
       }).catch((error) => {
         console.log("ERROR "+error);
   });
  }
  catch(error)
  {
    alert(error)
  }

alert(lastName+" "+mobile)




       }