import { Component, OnInit } from '@angular/core';

import {SignupService} from '../signup.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  display=false;
  apiData:object;
  constructor(private apiService:SignupService) { }

  ngOnInit() {

  }

  onClick(){
    if(this.display==false)
this.display=true;
else
{
  console.log(localStorage.getItem("fromDate"))
 
  this.display=false;
} 
}

}
